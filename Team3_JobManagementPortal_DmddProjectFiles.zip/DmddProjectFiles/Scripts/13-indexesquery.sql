/*index to display the count of applicants' education level for each state.*/
create index applicants_by_state
on applicant_profile (state, highest_education);


/*index to display the average of applicants' current salary for each city.*/
create index applicants_salary
on applicant_profile (city, current_salary);


create index user_2022 
on user_account(EXTRACT(YEAR from registration_date));

--inserting job skill data--
execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(2,'Beginner',1);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(9,'Proficient',2);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(7,'Proficient',3);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(5,'Contractor',4);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(3,'Proficient',5);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(6,'Proficient',6);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(14,'Beginner',7);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(10,'Proficient',8);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(7,'Proficient',9);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(10,'Proficient',10);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(19,'Proficient',11);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(19,'Contractor',12);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(8,'Beginner',13);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(20,'Proficient',14);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(18,'Proficient',15);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(19,'Contractor',16);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(21,'Proficient',17);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(16,'Proficient',18);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(1,'Beginner',19);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(11,'Proficient',20);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(3,'Proficient',21);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(1,'Proficient',22);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(1,'Beginner',23);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(3,'Proficient',24);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(2,'Beginner',25);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(16,'Proficient',26);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(4,'Beginner',27);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(10,'Proficient',28);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(10,'Proficient',29);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(12,'Proficient',30);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(5,'Beginner',31);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(6,'Proficient',32);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(11,'Proficient',33);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(11,'Proficient',34);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(9,'Contractor',35);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(9,'Proficient',36);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(6,'Beginner',37);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(4,'Beginner',38);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(5,'Contractor',39);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(5,'Beginner',40);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(14,'Beginner',41);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(15,'Beginner',42);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(21,'Proficient',43);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(17,'Beginner',44);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(12,'Proficient',45);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(2,'Beginner',46);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(4,'Proficient',47);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(7,'Beginner',48);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(7,'Beginner',49);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(7,'Beginner',50);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(2,'Beginner',51);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(9,'Proficient',52);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(7,'Proficient',53);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(5,'Contractor',54);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(3,'Proficient',55);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(6,'Proficient',56);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(14,'Beginner',57);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(10,'Proficient',58);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(7,'Proficient',59);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(10,'Proficient',60);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(19,'Proficient',61);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(19,'Contractor',62);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(8,'Beginner',63);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(20,'Proficient',64);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(18,'Proficient',65);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(19,'Contractor',66);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(21,'Proficient',67);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(16,'Proficient',68);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(1,'Beginner',69);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(11,'Proficient',70);
execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(3,'Proficient',71);
execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(1,'Proficient',72);
execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(1,'Beginner',73);
execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(3,'Proficient',74);
execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(2,'Beginner',75);
execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(1,'Proficient',76);
execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(4,'Beginner',77);
execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(10,'Proficient',78);
execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(10,'Proficient',79);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(12,'Proficient',80);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(5,'Beginner',81);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(6,'Proficient',82);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(11,'Proficient',83);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(11,'Proficient',84);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(9,'Contractor',85);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(9,'Proficient',86);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(6,'Beginner',87);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(4,'Beginner',88);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(5,'Contractor',89);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(5,'Beginner',90);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(14,'Beginner',91);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(15,'Beginner',92);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(21,'Proficient',93);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(17,'Beginner',94);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(12,'Proficient',95);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(2,'Beginner',96);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(4,'Proficient',97);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(7,'Beginner',98);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(7,'Beginner',99);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(7,'Beginner',100);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(2,'Beginner',101);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(9,'Proficient',102);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(7,'Proficient',103);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(5,'Contractor',104);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(3,'Proficient',105);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(6,'Proficient',106);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(14,'Beginner',107);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(10,'Proficient',108);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(7,'Proficient',109);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(10,'Proficient',110);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(19,'Proficient',111);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(19,'Contractor',112);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(8,'Beginner',113);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(20,'Proficient',114);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(18,'Proficient',115);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(19,'Contractor',116);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(21,'Proficient',117);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(16,'Proficient',118);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(1,'Beginner',119);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(11,'Proficient',120);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(3,'Proficient',121);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(1,'Proficient',122);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(1,'Beginner',123);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(3,'Proficient',124);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(2,'Beginner',125);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(16,'Proficient',126);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(4,'Beginner',127);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(10,'Proficient',128);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(10,'Proficient',129);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(12,'Proficient',130);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(5,'Beginner',131);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(6,'Proficient',132);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(11,'Proficient',133);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(11,'Proficient',134);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(9,'Contractor',135);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(9,'Proficient',136);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(6,'Beginner',137);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(4,'Beginner',138);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(5,'Contractor',139);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(5,'Beginner',140);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(14,'Beginner',141);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(15,'Beginner',142);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(21,'Proficient',143);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(17,'Beginner',144);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(12,'Proficient',145);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(2,'Beginner',146);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(4,'Proficient',147);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(7,'Beginner',148);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(7,'Beginner',149);

execute DMDDJOBPORTALSYSADMIN.sp_insert_jobskill(7,'Beginner',150);



